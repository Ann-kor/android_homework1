package com.example.homework1;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
public class MainActivity extends AppCompatActivity {
    private Button yes;
    public String string;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button yes=(Button)findViewById(R.id.yes);
        yes.setOnClickListener(new MyClick());
    }
    public  void onRadio1Click(View view){
        //使用土司弹出信息:
        RadioButton radioButton = findViewById(view.getId());
        this.string = (String)radioButton.getText();
        Toast.makeText(MainActivity.this, //要显示到哪一界面上
                this.string,                             //要显示的信息
                Toast.LENGTH_SHORT).show();        //显示的时间
    }
    public  void onRadio2Click(View view){
        //使用土司弹出信息:
        RadioButton radioButton = findViewById(view.getId());
        this.string = (String)radioButton.getText();
        //System.out.println(this.string);
        Toast.makeText(MainActivity.this, //要显示到哪一界面上
                this.string,                             //要显示的信息
                Toast.LENGTH_SHORT).show();        //显示的时间

    }

    class MyClick implements View.OnClickListener{
        @Override
        public void onClick(View view) {
            // 打开另一个activity，通过意图，意图作用是激活其他组件
            Intent intent = new Intent();
            //System.out.println(string);
            intent.setClass(MainActivity.this, SecondActivity.class);
            intent.putExtra("n",string);
//发送意图.将意图发送给android系统，系统根据意图来激活组件
            startActivity(intent);
        }
    }

}
