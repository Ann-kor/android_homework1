package com.example.homework1;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

@SuppressLint("Registered")
public class SecondActivity extends Activity implements android.widget.CompoundButton.OnCheckedChangeListener{
    //图片的数据区
    private ImageView mImageView1;
    private ImageView mImageView2;
    private int[] imageIds = new int[2];//要显示的图片数组
    private int i = 0;
    private String show;//显示的字符串
    //spinner的数据区
    private List<CharSequence> numList = null;//显示的内容
    private ArrayAdapter<CharSequence> numAdapter = null;//适配器
    private Spinner numSpinner= null;
    //文字数据区
    private TextView mytext;
    //滑动条
    private SeekBar seekBar;

//监听页面加载
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        Intent intent = getIntent();
        String val = intent.getStringExtra("n");
        if(val.equals("海贼王")){
            imageIds[0]=R.drawable.luffy;
            imageIds[1]=R.drawable.law;
            System.out.println(val);
            show = "原来你喜欢海贼王啊！";
        }
        else if(val.equals("火影忍者")){
            imageIds[0]=R.drawable.naruto;
            imageIds[1]=R.drawable.sasuki;
            System.out.println(val);
            show = "原来你喜欢火影忍者啊！";
        }
        else if(val.equals("灌篮高手")){
            imageIds[0]=R.drawable.sakuraki;
            imageIds[1]=R.drawable.lukawa;
            System.out.println(val);
            show = "原来你喜欢灌篮高手啊！";
        }
        else{
            imageIds[0]=R.drawable.kong;
            imageIds[1]=R.drawable.kong;
            System.out.println(val);
            show = "原来你啥都没选啊！";
        }
        mytext = (TextView)findViewById(R.id.tv);
        mytext.setText(show.toString());
        //找到Spinner控件
        numSpinner = (Spinner)super.findViewById(R.id.numSpinner);
        numSpinner.setPrompt("请选择显示的图片数:");
        numList = new ArrayList<CharSequence>();
        numList.add("1");
        numList.add("2");
        numAdapter = new ArrayAdapter<CharSequence>(this,android.R.layout.simple_spinner_item,numList);
        numAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        numSpinner.setAdapter(numAdapter);
        numSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {
                // 在选中之后触发
                String opt=parent.getItemAtPosition(position).toString();
                Toast.makeText(SecondActivity.this, //要显示到哪一界面上
                        opt,                             //要显示的信息
                        Toast.LENGTH_SHORT).show();        //显示的时间
                SecondActivity sa = new SecondActivity();
                Toast.makeText(SecondActivity.this, //要显示到哪一界面上
                        opt,                             //要显示的信息
                        Toast.LENGTH_SHORT).show();        //显示的时间
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                Toast.makeText(SecondActivity.this, //要显示到哪一界面上
                        "啊还没吃呢啊哈哈哈哈哈",                             //要显示的信息
                        Toast.LENGTH_SHORT).show();        //显示的时间
            }
        }
        );
//找到image控件
        mImageView1 = (ImageView) findViewById(R.id.image1);
        //给ImageView设置背景图片
        mImageView2 = (ImageView) findViewById(R.id.image2);
        mImageView1.setBackgroundResource(imageIds[0]);
        mImageView2.setBackgroundResource(imageIds[1]);

        //seekbar
        seekBar = (SeekBar) findViewById(R.id.sb);
        seekBar.setMax(100);
        seekBar.setOnSeekBarChangeListener(listener);
    }
    // 定义一个监听器，该监听器负责监听进度条状态的改变
    private SeekBar.OnSeekBarChangeListener listener = new SeekBar.OnSeekBarChangeListener() {
        // 当用户停止滑动滑块的时候，调用此方法
        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {
            Toast.makeText(SecondActivity.this, "onStopTrackingTouch方法",
                    Toast.LENGTH_LONG).show();
        }

        // 当用户开始滑动滑块的时候，调用此方法
        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {
            Toast.makeText(SecondActivity.this, "onStartTrackingTouch方法",
                    Toast.LENGTH_LONG).show();
        }

        // 当进度条的进度方式变化的时候，就会调用这个方法
        // 只要进度条的滑块发生变化，无论滑块是怎样变化的，都会调用此方法
        @Override
        public void onProgressChanged(SeekBar seekBar, int progress,
                                      boolean fromUser) {
            Toast.makeText(SecondActivity.this, "onProgressChanged方法",
                    Toast.LENGTH_LONG).show();
        }
    };
    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

    }

}